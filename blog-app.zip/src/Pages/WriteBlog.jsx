import React from "react";
import BlogsForm from "../Common/BlogsForm";


export default function WriteBlog() {
  return (
    <div className="container-fluid">
        <div className="container text-start">
      <h1>Write Blog</h1>
      <BlogsForm />
      <div className=""></div>

        </div>
      
    </div>
  );
}
